# face > 2024-10-23 2:17pm
https://universe.roboflow.com/aditya-pandey-hwes0/face-ape5v-k4kec-kxmoo-kmice

Provided by a Roboflow user
License: CC BY 4.0

